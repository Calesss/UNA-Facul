function ImprimirTabuada(texto) {
    document.getElementById("resultado").innerHTML += texto;
  }
  
  function executar(ev) {
    ev.preventDefault();
    var resultado = "<table><tr>";

    i = document.getElementById("tabuadavalor").value;

      for (var j=0; j<=10; j=j+1) {
        var multiplicacao = i*j;
        var linha = "" + i + "x" + j + "=" + multiplicacao + "<br>";
        resultado = resultado + linha;
      }

    resultado = resultado + "</tr></table><br>";
    ImprimirTabuada(resultado);
  
  }